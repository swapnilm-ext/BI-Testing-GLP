﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data;

public partial class vessel : System.Web.UI.Page
{
    protected void Page_PreInit(object sender, EventArgs e)
    {
        this.Theme = "SkinFile";
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ShowDiv("ShowGrid", false);
            Session["SortDirection"] = "DESC";
            //===============
            GridBind();
            //===============
        }
    }
    public void GridBind(string SortExpression = "")
    {
        using (vessel_BL obj = new vessel_BL())
        {
            DataView dv = obj.Getvessel().DefaultView;
            if (Session["SortDirection"].ToString().Equals("DESC"))
            {
                Session["SortDirection"] = "ASC";
            }
            else
            {
                Session["SortDirection"] = "DESC";
            }
            if (!SortExpression.Equals(string.Empty))
            {
                dv.Sort = SortExpression + " " + Session["SortDirection"].ToString();
            }
            grdvessel.DataSource = dv;
            grdvessel.DataBind();
        }
    }
    public void ShowDiv(string str, bool IsSave)
    {
        if (str.Equals("Add_New"))
        {
            divform.Visible = true;
            divgrd.Visible = false;
            if (IsSave)
            {
                btnsave.Visible = true;
                btnupdate.Visible = false;
            }
            else
            {
                btnsave.Visible = false;
                btnupdate.Visible = true;
            }
        }
        else
        {
            divform.Visible = false;
            divgrd.Visible = true;
        }
    }
    public void SetEditControls(int RowId)
    {
        lblid.Text = grdvessel.Items[RowId].Cells[0].Text.ToString();
        txtname.Text = grdvessel.Items[RowId].Cells[1].Text.ToString();
        txtimo.Text = grdvessel.Items[RowId].Cells[2].Text.ToString();
        txtmmsi.Text = grdvessel.Items[RowId].Cells[3].Text.ToString();
        txtcall_sign.Text = grdvessel.Items[RowId].Cells[4].Text.ToString();
        txtflag.Text = grdvessel.Items[RowId].Cells[5].Text.ToString();
        txtais_type.Text = grdvessel.Items[RowId].Cells[6].Text.ToString();
        txtgross_tonnage.Text = grdvessel.Items[RowId].Cells[7].Text.ToString();
        txtdeadweight.Text = grdvessel.Items[RowId].Cells[8].Text.ToString();
        txtlength_breadth.Text = grdvessel.Items[RowId].Cells[9].Text.ToString();
        txtyear_built.Text = grdvessel.Items[RowId].Cells[10].Text.ToString();
        txtstatus.Text = grdvessel.Items[RowId].Cells[11].Text.ToString();
    }
    public void Reset()
    {
        txtname.Text = string.Empty;
        txtimo.Text = string.Empty;
        txtmmsi.Text = string.Empty;
        txtcall_sign.Text = string.Empty;
        txtflag.Text = string.Empty;
        txtais_type.Text = string.Empty;
        txtgross_tonnage.Text = string.Empty;
        txtdeadweight.Text = string.Empty;
        txtlength_breadth.Text = string.Empty;
        txtyear_built.Text = string.Empty;
        txtstatus.Text = string.Empty;
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        //===============
        ShowDiv("ShowGrid", false);
        //===============
        Reset();
        //===============
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        using (vessel_BL obj = new vessel_BL())
        {
            ArrayList arr = new ArrayList();
            arr.Add("Name");
            arr.Add("IMO");
            arr.Add("MMSI");
            arr.Add("Call_Sign");
            arr.Add("Flag");
            arr.Add("AIS_Type");
            arr.Add("Gross_Tonnage");
            arr.Add("Deadweight");
            arr.Add("Length_Breadth");
            arr.Add("Year_Built");
            arr.Add("Status");
            grdvessel.CurrentPageIndex = 0;
            grdvessel.DataSource = CommonFunctions.SearchDataTable(txtsearch.Text, arr, obj.Getvessel());
            grdvessel.DataBind();
        }
    }
    protected void btnaddnew_Click(object sender, EventArgs e)
    {
        ShowDiv("Add_New", true);
    }
    protected void grdvessel_ItemCommand(object source, DataGridCommandEventArgs e)
    {
        if (e.CommandName.ToString().Equals("Edit"))
        {
            ShowDiv("Add_New", false);
            SetEditControls(e.Item.ItemIndex);
        }
        else if (e.CommandName.ToString().Equals("Delete"))
        {
            using (vessel_BL objbl = new vessel_BL())
            {
                objbl.Id = Convert.ToInt32(grdvessel.Items[e.Item.ItemIndex].Cells[0].Text.ToString());
                objbl.Deletevessel(objbl);
                //====================================
                GridBind();
                //====================================
            }
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        using (vessel_BL objbl = new vessel_BL())
        {
            objbl.Name = txtname.Text.ToString();
            objbl.IMO = txtimo.Text.ToString();
            objbl.MMSI = txtmmsi.Text.ToString();
            objbl.Call_Sign = txtcall_sign.Text.ToString();
            objbl.Flag = txtflag.Text.ToString();
            objbl.AIS_Type = txtais_type.Text.ToString();
            objbl.Gross_Tonnage = txtgross_tonnage.Text.ToString();
            objbl.Deadweight = txtdeadweight.Text.ToString();
            objbl.Length_Breadth = txtlength_breadth.Text.ToString();
            objbl.Year_Built = txtyear_built.Text.ToString();
            objbl.Status = txtstatus.Text.ToString();
            //============================
            int result = objbl.Insertvessel(objbl);
            //============================
            ShowDiv("ShowGrid", false);
            //===============
            GridBind();
            //===============
            Reset();
            //===============
        }
    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        //===============
        Reset();
        //===============
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        using (vessel_BL objbl = new vessel_BL())
        {
            objbl.Id = Convert.ToInt32(lblid.Text.ToString());
            objbl.Name = txtname.Text.ToString();
            objbl.IMO = txtimo.Text.ToString();
            objbl.MMSI = txtmmsi.Text.ToString();
            objbl.Call_Sign = txtcall_sign.Text.ToString();
            objbl.Flag = txtflag.Text.ToString();
            objbl.AIS_Type = txtais_type.Text.ToString();
            objbl.Gross_Tonnage = txtgross_tonnage.Text.ToString();
            objbl.Deadweight = txtdeadweight.Text.ToString();
            objbl.Length_Breadth = txtlength_breadth.Text.ToString();
            objbl.Year_Built = txtyear_built.Text.ToString();
            objbl.Status = txtstatus.Text.ToString();
            //============================
            int result = objbl.Updatevessel(objbl);
            //============================
            ShowDiv("ShowGrid", false);
            //===============
            GridBind();
            //===============
            Reset();
            //===============
        }
    }
    protected void grdvessel_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
    {
        grdvessel.CurrentPageIndex = e.NewPageIndex;
        if (Session["SortDirection"].ToString().Equals("DESC"))
        {
            Session["SortDirection"] = "ASC";
        }
        else
        {
            Session["SortDirection"] = "DESC";
        }
        //===============
        GridBind();
        //===============
    }
    protected void grdvessel_SortCommand(object source, DataGridSortCommandEventArgs e)
    {
        GridBind(e.SortExpression);
    }

}