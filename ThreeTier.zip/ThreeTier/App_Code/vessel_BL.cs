﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

public class vessel_BL:IDisposable
{
	public vessel_BL()
	{
		
	}
    vessel_DL objdl = new vessel_DL();
 #region ""Properties"
   private int _Id;
    public int Id
      {
       get{ return _Id;}
       set{ _Id=value;}
      }

   private string _Name;
    public string Name
      {
       get{ return _Name;}
       set{ _Name=value;}
      }

   private string _IMO;
    public string IMO
      {
       get{ return _IMO;}
       set{ _IMO=value;}
      }

   private string _MMSI;
    public string MMSI
      {
       get{ return _MMSI;}
       set{ _MMSI=value;}
      }

   private string _Call_Sign;
    public string Call_Sign
      {
       get{ return _Call_Sign;}
       set{ _Call_Sign=value;}
      }

   private string _Flag;
    public string Flag
      {
       get{ return _Flag;}
       set{ _Flag=value;}
      }

   private string _AIS_Type;
    public string AIS_Type
      {
       get{ return _AIS_Type;}
       set{ _AIS_Type=value;}
      }

   private string _Gross_Tonnage;
    public string Gross_Tonnage
      {
       get{ return _Gross_Tonnage;}
       set{ _Gross_Tonnage=value;}
      }

   private string _Deadweight;
    public string Deadweight
      {
       get{ return _Deadweight;}
       set{ _Deadweight=value;}
      }

   private string _Length_Breadth;
    public string Length_Breadth
      {
       get{ return _Length_Breadth;}
       set{ _Length_Breadth=value;}
      }

   private string _Year_Built;
    public string Year_Built
      {
       get{ return _Year_Built;}
       set{ _Year_Built=value;}
      }

   private string _Status;
    public string Status
      {
       get{ return _Status;}
       set{ _Status=value;}
      }

#endregion
   public DataTable Getvessel()
    {
     return objdl.Getvessel();
    }
   public DataTable Getvessel(vessel_BL objbl)
    {
     return objdl.Getvessel(objbl);
    }
   public int Deletevessel()
    {
     return objdl.Deletevessel();
    }
   public int Deletevessel(vessel_BL objbl)
    {
     return objdl.Deletevessel(objbl);
    }
   public int Insertvessel(vessel_BL objbl)
    {
     return objdl.Insertvessel(objbl);
    }
   public int Updatevessel(vessel_BL objbl)
    {
     return objdl.Updatevessel(objbl);
    }

    public void Dispose()     {     } 
}