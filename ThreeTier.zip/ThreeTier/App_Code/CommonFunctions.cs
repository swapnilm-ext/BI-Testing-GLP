﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Collections;

/// <summary>
/// Summary description for CommonFunctions
/// </summary>
public class CommonFunctions
{
    public CommonFunctions()
    {

    }
    public static DataTable SearchDataTable(String strKeyword, ArrayList arrcolumnname, DataTable dt)
    {
        string strwhere = string.Empty;
        for (int i = 0; i < arrcolumnname.Count; i++)
        {
            if (i < arrcolumnname.Count - 1)
            {
                strwhere = strwhere + arrcolumnname[i].ToString() + " like '%" + strKeyword + "%' or ";
            }
            else
            {
                strwhere = strwhere + arrcolumnname[i].ToString() + " like '%" + strKeyword + "%'";
            }
        }
        DataRow[] dtRow = dt.Select(strwhere);
        DataTable dtTable = new DataTable();
        dtTable = dt.Clone();
        for (int i = 0; i < dtRow.Length; i++)
        {
            dtTable.ImportRow(dtRow[i]);
        }
        return dtTable;
    }

}