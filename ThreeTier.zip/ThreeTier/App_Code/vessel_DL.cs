﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
public class vessel_DL
{
	public vessel_DL()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public DataTable Getvessel()
    {
        DataTable dt = new DataTable();
        try
        {
            SqlDataAdapter da = new SqlDataAdapter("vesselSelectAllSp", Coneection.cn);
            Coneection.cn.Open();
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.Fill(dt);
            return dt;
        }
        catch (Exception ex)
        {
            return dt;
        }
        finally
        {
            Coneection.cn.Close();
        }
    }
    public DataTable Getvessel(vessel_BL objvessel)
    {
        DataTable dt = new DataTable();
        try
        {
            SqlDataAdapter da = new SqlDataAdapter("vesselSelectBy_IdSp", Coneection.cn);
            Coneection.cn.Open();
            da.SelectCommand.Parameters.Add(new SqlParameter("@Id", objvessel.Id));
            int Issuccess = 0;
            da.SelectCommand.Parameters.Add(new SqlParameter(@"Issuccess", Issuccess));
            da.SelectCommand.Parameters[@"Issuccess"].Direction = ParameterDirection.Output;
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.Fill(dt);
            return dt;
        }
        catch (Exception ex)
        {
            return dt;
        }
        finally
        {
            Coneection.cn.Close();
        }
    }
    public int Deletevessel()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("vesselDeleteSp", Coneection.cn);
            Coneection.cn.Open();

            cmd.CommandType = CommandType.StoredProcedure;
            return cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            return 0;
        }
        finally
        {
            Coneection.cn.Close();
        }
    }
    public int Deletevessel(vessel_BL objvessel)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("vesselDeleteBy_Id_Sp", Coneection.cn);
            Coneection.cn.Open();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@Id", objvessel.Id));
            int Issuccess = 0;
            cmd.Parameters.Add(new SqlParameter(@"Issuccess", Issuccess));
            cmd.Parameters[@"Issuccess"].Direction = ParameterDirection.Output;
            cmd.CommandType = CommandType.StoredProcedure;
            return cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            return 0;
        }
        finally
        {
            Coneection.cn.Close();
        }
    }
    public int Insertvessel(vessel_BL objvessel)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("vesselInsertSp", Coneection.cn);
            Coneection.cn.Open();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@Name", objvessel.Name));
            cmd.Parameters.Add(new SqlParameter("@IMO", objvessel.IMO));
            cmd.Parameters.Add(new SqlParameter("@MMSI", objvessel.MMSI));
            cmd.Parameters.Add(new SqlParameter("@Call_Sign", objvessel.Call_Sign));
            cmd.Parameters.Add(new SqlParameter("@Flag", objvessel.Flag));
            cmd.Parameters.Add(new SqlParameter("@AIS_Type", objvessel.AIS_Type));
            cmd.Parameters.Add(new SqlParameter("@Gross_Tonnage", objvessel.Gross_Tonnage));
            cmd.Parameters.Add(new SqlParameter("@Deadweight", objvessel.Deadweight));
            cmd.Parameters.Add(new SqlParameter("@Length_Breadth", objvessel.Length_Breadth));
            cmd.Parameters.Add(new SqlParameter("@Year_Built", objvessel.Year_Built));
            cmd.Parameters.Add(new SqlParameter("@Status", objvessel.Status));
            int Issuccess = 0;
            cmd.Parameters.Add(new SqlParameter("@Issuccess", Issuccess));
            cmd.Parameters["@Issuccess"].Direction = ParameterDirection.Output;
            return cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            return 0;
        }
        finally
        {
            Coneection.cn.Close();
        }
    }
    public int Updatevessel(vessel_BL objvessel)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("vesselUpdateSp", Coneection.cn);
            Coneection.cn.Open();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@Id", objvessel.Id));
            cmd.Parameters.Add(new SqlParameter("@Name", objvessel.Name));
            cmd.Parameters.Add(new SqlParameter("@IMO", objvessel.IMO));
            cmd.Parameters.Add(new SqlParameter("@MMSI", objvessel.MMSI));
            cmd.Parameters.Add(new SqlParameter("@Call_Sign", objvessel.Call_Sign));
            cmd.Parameters.Add(new SqlParameter("@Flag", objvessel.Flag));
            cmd.Parameters.Add(new SqlParameter("@AIS_Type", objvessel.AIS_Type));
            cmd.Parameters.Add(new SqlParameter("@Gross_Tonnage", objvessel.Gross_Tonnage));
            cmd.Parameters.Add(new SqlParameter("@Deadweight", objvessel.Deadweight));
            cmd.Parameters.Add(new SqlParameter("@Length_Breadth", objvessel.Length_Breadth));
            cmd.Parameters.Add(new SqlParameter("@Year_Built", objvessel.Year_Built));
            cmd.Parameters.Add(new SqlParameter("@Status", objvessel.Status));
            int Issuccess = 0;
            cmd.Parameters.Add(new SqlParameter("@Issuccess", Issuccess));
            return cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            return 0;
        }
        finally
        {
            Coneection.cn.Close();
        }
    }

}