﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    [WebMethod]
    public static string Getvessel()
    {
        using (vessel_BL obj = new vessel_BL())
        {
            return JsonConvert.SerializeObject(obj.Getvessel());
        }
    }
    [WebMethod]
    public static string Deletevessel(string Id)
    {
        using (vessel_BL obj = new vessel_BL())
        {
            obj.Id = Convert.ToInt32(Id);
            return JsonConvert.SerializeObject(obj.Deletevessel(obj));
        }
    }


    
    [WebMethod]
    public static string AddNewvessel(string Name, string IMO, string MMSI,string Call_Sign, string Flag, string AIS_Type, string Gross_Tonnage, string Deadweight, string Length_Breadth, string Year_Built, string Status)
    {
        using (vessel_BL obj = new vessel_BL())
        {
            obj.Name = Name;
            obj.IMO = IMO;
            obj.MMSI = MMSI;
            obj.Call_Sign = Call_Sign;
            obj.Flag = Flag;
            obj.AIS_Type = AIS_Type;
            obj.Gross_Tonnage = Gross_Tonnage;
            obj.Deadweight = Deadweight;
            obj.Length_Breadth = Length_Breadth;
            obj.Year_Built = Year_Built;
            obj.Status = Status;
            return JsonConvert.SerializeObject(obj.Insertvessel(obj));
        }
    }

    [WebMethod]
    public static string Updatevessel(string Id,string Name, string IMO, string MMSI, string Call_Sign, string Flag, string AIS_Type, string Gross_Tonnage, string Deadweight, string Length_Breadth, string Year_Built, string Status)
    {
        using (vessel_BL obj = new vessel_BL())
        {
            obj.Id = Convert.ToInt32(Id);
            obj.Name = Name;
            obj.IMO = IMO;
            obj.MMSI = MMSI;
            obj.Call_Sign = Call_Sign;
            obj.Flag = Flag;
            obj.AIS_Type = AIS_Type;
            obj.Gross_Tonnage = Gross_Tonnage;
            obj.Deadweight = Deadweight;
            obj.Length_Breadth = Length_Breadth;
            obj.Year_Built = Year_Built;
            obj.Status = Status;
            return JsonConvert.SerializeObject(obj.Updatevessel(obj));
        }
    }
}