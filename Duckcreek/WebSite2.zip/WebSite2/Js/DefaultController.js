﻿var app = angular.module('DefaultApp', []);
app.controller('DefaultController', function ($scope, httpcombinedservices) {

    function Getvessel() {
        httpcombinedservices.Getvessel().then(function (responce) { $scope.rows = JSON.parse(responce.data.d) });
    }


    $scope.init = function () {
        Getvessel();
        $scope.editMode = false;
    }
    $scope.edit = function (rowObject) {


        $scope.editMode = true;
        AddMode(false, true);
        $scope.Id = rowObject.Id;
        $scope.name = rowObject.Name;
        $scope.IMO = rowObject.IMO;
        $scope.MMSI = rowObject.MMSI;
        $scope.Call_Sign = rowObject.Call_Sign;
        $scope.Flag = rowObject.Flag;
        $scope.AIS_Type = rowObject.AIS_Type;
        $scope.Gross_Tonnage = rowObject.Gross_Tonnage;
        $scope.Deadweight = rowObject.Deadweight;
        $scope.Length_Breadth = rowObject.Length_Breadth;
        $scope.Year_Built = rowObject.Year_Built;
        $scope.Status = rowObject.Status;
    }


    $scope.delete = function (Id) {
        if (confirm('Do you want to delete this record.')) {
            httpcombinedservices.Deletevessel(Id).then(function (responce) {
                console.log(JSON.parse(responce.data.d));
                Getvessel();
                if (responce.data.d > 0) {
                    alert('Record deleted sucessfully');
                }
            });


        }
    }
    $scope.addNewRecord = function () {
        $scope.editMode = true;
        $scope.clear();
        AddMode(true, false);
    }

    $scope.cancel = function () {

        $scope.editMode = false;
    }

    $scope.Update = function () {
        var myObj = {}
        myObj["Id"] = $scope.Id;
        myObj["Name"] = $scope.name;
        myObj["IMO"] = $scope.IMO;
        myObj["MMSI"] = $scope.MMSI;
        myObj["Call_Sign"] = $scope.Call_Sign;
        myObj["Flag"] = $scope.Flag;
        myObj["AIS_Type"] = $scope.AIS_Type;
        myObj["Gross_Tonnage"] = $scope.Gross_Tonnage;
        myObj["Deadweight"] = $scope.Deadweight;
        myObj["Length_Breadth"] = $scope.Length_Breadth;
        myObj["Year_Built"] = $scope.Year_Built;
        myObj["Status"] = $scope.Status;


        httpcombinedservices.Updatevessel(myObj).then(function (responce) {
            if (responce.data.d > 0) {
                Getvessel();
                $scope.editMode = false;
                alert('Record Updated sucessfully');
            }
        });
    }

    $scope.Save = function () {
        var myObj = {}
        myObj["Name"] = $scope.name;
        myObj["IMO"] = $scope.IMO;
        myObj["MMSI"] = $scope.MMSI;
        myObj["Call_Sign"] = $scope.Call_Sign;
        myObj["Flag"] = $scope.Flag;
        myObj["AIS_Type"] = $scope.AIS_Type;
        myObj["Gross_Tonnage"] = $scope.Gross_Tonnage;
        myObj["Deadweight"] = $scope.Deadweight;
        myObj["Length_Breadth"] = $scope.Length_Breadth;
        myObj["Year_Built"] = $scope.Year_Built;
        myObj["Status"] = $scope.Status;


        httpcombinedservices.AddNewvessel(myObj).then(function (responce) {
            if (responce.data.d > 0) {
                Getvessel();
                $scope.editMode = false;
                alert('Record Added sucessfully');
            }
        });
    }


    $scope.clear = function () {
        $scope.name = '';
        $scope.IMO = '';
        $scope.MMSI = '';
        $scope.Call_Sign = '';
        $scope.Flag = '';
        $scope.AIS_Type = '';
        $scope.Gross_Tonnage = '';
        $scope.Deadweight = '';
        $scope.Length_Breadth = '';
        $scope.Year_Built = '';
        $scope.Status = '';
    }

    $scope.sortColumn = function (columnName) {
        $scope.orderByColumn = columnName;
        if ($scope.sortDirection) {
            $scope.sortDirection = false;
        }
        else {
            $scope.sortDirection = true;
        }
    };

    function AddMode(isAddmode, isUpdateMode) {
        $scope.showAddButton = isAddmode;
        $scope.showUpdateButton = isUpdateMode;
    }
})