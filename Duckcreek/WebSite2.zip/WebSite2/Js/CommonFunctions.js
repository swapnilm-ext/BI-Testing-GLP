﻿function ExecutenonQuery($http,url,method,async,cache,data) {
    return $http({
        url: url,
        method: method,
        async: async,
        cache: cache,
        data: data
    })
}
