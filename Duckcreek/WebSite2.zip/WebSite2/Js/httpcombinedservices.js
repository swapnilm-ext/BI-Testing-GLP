﻿app.service('httpcombinedservices', function ($http) {
    this.Getvessel = function () {
        return ExecutenonQuery($http, 'Default.aspx/Getvessel', 'POST', false, false, {});
    };
    this.Deletevessel = function (Id) {
        var myObj = {};
        myObj["Id"] = Id;
        var json = JSON.stringify(myObj);
        return ExecutenonQuery($http, 'Default.aspx/Deletevessel', 'POST', false, false, json);
    };
    this.AddNewvessel = function (obj) {
        var json = JSON.stringify(obj);
        return ExecutenonQuery($http, 'Default.aspx/AddNewvessel', 'POST', false, false, json);
    }

    this.Updatevessel = function (obj) {
        var json = JSON.stringify(obj);
        return ExecutenonQuery($http, 'Default.aspx/Updatevessel', 'POST', false, false, json);
    }

});