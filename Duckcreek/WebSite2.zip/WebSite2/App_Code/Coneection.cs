﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Coneection
/// </summary>
public class Coneection
{
	public Coneection()
	{
		
	}
    public static SqlConnection cn = new SqlConnection("Data Source = .; Initial Catalog = shipping; Integrated Security = SSPI;");
}